/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

(function (){
    var app = angular.module('stockmarket',[]);
    app.controller('MarketController',function ($scope){
        var marketCtrl = this;
        $scope.session = null;
        this.doLogin = function(){
            $scope.session= marketCtrl.users [$scope.enteredID];
        }
        this.users ={
            "123":{'name':'hamed','money':'2000'}
        };

        $scope.symbols = [
           { 'name': 'IRANKH', 'price': 20000 },
           { 'name': 'SAIPA', 'price': 100000 },
           { 'name': 'BMW', 'price': 900000 },
           { 'name': 'BENZ', 'price': 800000 }
        ];
    });
})();